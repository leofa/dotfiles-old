#!/bin/bash
#
# 64px folders
#
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-documents.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-download.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-downloads.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-music.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-network.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-pictures.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-publicshare.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-templates.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/folder-videos.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/64/user-home.svg
# 48px folders
#
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-documents.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-download.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-downloads.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-music.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-network.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-pictures.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-publicshare.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-templates.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/folder-videos.svg
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/48/user-home.svg
#
# 128px folder
./replace_folder_file.sh /home/faruk/.local/share/icons/Flattr/places/128/folder.svg
